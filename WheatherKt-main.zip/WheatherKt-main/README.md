# WheatherKt
wheather app with kotlin
Retrofit

<img width="289" alt="Screenshot 1402-10-24 at 8 15 05 in the evening" src="https://github.com/shirinvn/WheatherKt/assets/62846862/877123ea-945e-4b76-bbd7-c55dccdfd509">
<img width="289" alt="Screenshot 1402-10-24 at 8 15 50 in the evening" src="https://github.com/shirinvn/WheatherKt/assets/62846862/535a49c5-672e-4135-a255-f3e3981f2e67">
<img width="289" alt="Screenshot 1402-10-24 at 8 15 32 in the evening" src="https://github.com/shirinvn/WheatherKt/assets/62846862/44ef5246-c6eb-4312-9bcf-9e0a4dd4f8f3">

